//Name: Vijayagopal Krishnan (V.J)
//NetID:vxk131830
//CS 1337 S02
// Date: 11/20/2015

#include "LinkedList.h"
#include "Node.h"
#include <iostream>
using namespace std;


bool isBegginingOfTrig(char);
bool isEndOfCoefficient(char);
bool isEndOfExpression(char, char);
bool isBegginingOfExpo(char);

int main()
{
 // Declaring objects and variables needed
  LinkedList lister;
  ifstream input ("functions.txt");
  fstream output("derive.txt", ios::out | ios::app);
  int coeff = 0;
  int expo = 0;
  char coeffSign = '+';
  char expoSign = '+';
  char* trigFunc = new char [10];
  int trigCoeff = 0;
  char current;
  char previous;
  Node node;

  // loop until the end of the file
  while (!(input.eof()))
   {
     previous = current;
     input.get(current);
     while (current != '\n')
      {
        // Used to record values for the coefficient, exponent, trig coefficient and trig function when reading the file
        char * coeffArray = new char;
        char * expoArray = new char[2];
        char * trigCoeffArray = new char;
        char* trigArray = new char [3];
        int coeffIndex = 0;
        int expoIndex = 0;
        int trigIndex = 0;
        int trigCoeffIndex = 0;
        // checks if the character is a "-" or a "+"
        if(current == '-')
         {
          coeffSign = current;
          previous = current;
          input.get(current);
         }
        if (current == '+')
         {
          coeffSign = current;
          previous = current;
          input.get(current);
         }
        if (current == ' ')
         {
          previous = current;
          input.get(current);
         }
        // checks if the character is a digit and if it is, records it in the coeff array along with other characters that are digits
        if (isdigit(current))
         {
          do
           {
            *(coeffArray+coeffIndex) = current;
            coeffIndex++;
            previous = current;
            input.get(current);
           } while (!isEndOfCoefficient(current)); // checks if the input file is at the end of the coefficient or not
          coeff = atoi(coeffArray); // converts the characters recorded in the coeff array to numbers
          if (!(isEndOfExpression(previous, current))) // checks if the file reached the end of an expression or not
           {
            if (current == 'x') // checks if the next character is x or not which indicates an exponent
             {
              expo = 1;
              previous = current;
              input.get(current);
              if (isBegginingOfExpo(current)) // checks if there's an exponent value or not
               {
                 if (current == '-')
                  {
                   expoSign = current;
                   input.get(current);
                  }
                 else
                  {
                   expoSign = '+';
                   input.get(current);
                  }
                 do
                 {
                  *(expoArray+expoIndex) = current;
                  expoIndex++;
                  input.get(current);
                 } while (!isEndOfCoefficient(current));
                expo = atoi(expoArray); // converts the characters recorded in expo array into numbers for the expo to hold as it's value
             }
           }
        else if (isBegginingOfTrig(current)) // checks if the input file is reading a trig function or not
         {
          while (trigIndex < 3)
           {
            trigArray[trigIndex] = current;
            trigIndex++;
            input.get(current);
            }
           strcpy(trigFunc,trigArray); // transfers the value in the trigArray to trigFunc
           input.get(current);
           if(isdigit(current)) // checks if there's a trig coefficient or not
            {
             do
              {
               *(trigCoeffArray+trigCoeffIndex) = current;
               trigCoeffIndex++;
               previous = current;
               input.get(current);
              } while (!isEndOfCoefficient(current));
              trigCoeff= atoi(trigCoeffArray); // converts the characters recorded in trigCoeffArray to numbers for trigCoeff to hold
            }
           else
            trigCoeff = 1;
         }
       }
      else
        {
         expo = 0;
         strcpy(trigFunc,"/0");
         trigCoeff = 0;
        }
    }
   else
    {
      coeff = 1;
      if (current == 'x')
       {
        expo = 1;
        input.get(current);
        if (isBegginingOfExpo(current))
         {
          {
            if (current == '-')
             {
               expoSign = current;
               input.get(current);
              }
             else
               expoSign = '+';
             do
              {
                *(expoArray+expoIndex) = current;
                expoIndex++;
                input.get(current);
              } while (isdigit(current));
             expo = atoi(expoArray);
            }
          }
        }
       else if (isBegginingOfTrig(current))
        {
         while (trigIndex < 3)
           {
            trigArray[trigIndex] = current;
            trigIndex++;
            input.get(current);
           }
          strcpy(trigFunc,trigArray);
          trigIndex = 0;
          input.get(current);
          if(isdigit(current))
           {
             do
              {
                *(trigCoeffArray+trigCoeffIndex) = current;
                trigCoeffIndex++;
                previous = current;
                input.get(current);
              } while (!isEndOfCoefficient(current));
              trigCoeff= atoi(trigCoeffArray);
            }
           else
            trigCoeff = 1;
         }
        else
         {
           expo = 0;
           strcpy(trigFunc,"/0");
           trigCoeff = 0;
         }
       }
    // Sets all the values recorded to the attributes of the node object
    node.setCoefficient(coeff);
    node.setExponent(expo);
    node.setCoefficientSign(coeffSign);
    node.setExponentSign(expoSign);
    node.setTrigFunction(trigFunc);
    node.setTrigCoefficient(trigCoeff);
    // derives the node
    node.deriveNode();
    // Adds the node to the linked list object
    lister.addNode(&node);
    // checks if the file is not at the end of the line in case of spaces
    if (current != '\n')
       {
        previous = current;
        input.get(current);
        while (current == ' ')
         {
          previous = current;
          input.get(current);
         }
       }
// deletes memory created by these variables
    delete coeffArray;
    delete expoArray;
    delete trigArray;
    delete trigCoeffArray;
    // prints the Linked List object to the output file
  lister.printNodes(output);
  // deletes all the nodes in the linked list object
  lister.deleteNodes();
   }
  output << "\n";
 }
}

// Checks if the character read by the file is at the end of the coefficient
bool isEndOfCoefficient(char ch)
{
    if (!isdigit(ch))
        return true;
    return false;
}
//checks if the character read by the file is at the end of the expression or not
bool isEndOfExpression (char previous, char current)
{
  if ((current == '+') || (current == '-'))
    {
      if (previous != '^' || previous != 'x' || isdigit(previous) || (previous == ' '))
            return true;
        else
            return false;
    }
    else if (current == '\n')
        return true;
    return false;
}
//checks if the character read by the file is an indication of the beginning of the string or not
bool isBegginingOfTrig(char ch)
{
  if (!(isdigit(ch)) && (ch != 'x') && (ch != '+') && (ch != '-') && (ch != '^') && (ch != ' '))
    return true;
  return false;
}
//checks if the character read by the file is an indication of the beginning of an exponent or not
bool isBegginingOfExpo(char ch)
{
  if (ch == '^')
     return true;
  return false;
}
