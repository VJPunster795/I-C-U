//Name: Vijayagopal Krishnan (V.J)
//NetID:vxk131830
//CS 1337 S02
// Date: 11/20/2015

#include "LinkedList.h"
#include <iostream>
#include <fstream>

//Adds a node recursively if the head node is occupied
void addNodeRec(Node* current, Node *node)
{
  if (!(current->next))
  {
    current->next = node;
    node->next = nullptr;
  }
  else
  {
    addNodeRec((current->next),node);
   }
}

// Adds a node to the head if the list is empty
void LinkedList:: addNode (Node * node)
{
 if (!headPointer)
 {
    headPointer = node;
    node->next = nullptr;
}
else
    addNodeRec((headPointer),node);
}
//deletes all the nodes in the Linked List
void LinkedList:: deleteNodes()
{
  if (!headPointer)
    return;
  headPointer = nullptr;
}

// Prints the nodes recursively
void printNodesRec(Node * current, fstream &output)
{
    if (!current)
        return;
    else
    {
      if (current->isTrigExpression())
       {
        output << current->getCoefficientSign() << current->getCoefficient() << current->getTrigFunction() << " " << current->getTrigCoefficient() << "x" << " ";
       }
      else
       {
        output << current->getCoefficientSign() << current->getCoefficient() << "x" << "^" << current->getExponentSign() << current->getExponent() << " ";
       }
    }
}

// uses a helper function to print the nodes.
void LinkedList::printNodes(fstream &output)
{
  printNodesRec(headPointer, output);
}


