//Name: Vijayagopal Krishnan (V.J)
//NetID:vxk131830
//CS 1337 S02
// Date: 11/20/2015

#ifndef NODE_H_INCLUDED
#define NODE_H_INCLUDED

#include <fstream>
#include <cstdlib>
#include <cstring>
using namespace std;
class Node
{
    public:
        Node();
        Node (int, int, char, char, char*, int);
        ~Node() {}
        //Accessors
        int getCoefficient()
        {
            return coefficient;
        }
        int getExponent()
        {
            return exponent;
        }
        char getCoefficientSign()
        {
            return coefficientSign;
        }
        char getExponentSign()
        {
            return exponentSign;
        }
        char * getTrigFunction()
        {
            return trigFunction;
        }
        int getTrigCoefficient()
        {
            return trigCoefficient;
        }
        //Prototype methods (includes mutators)
        void deriveNode();
        bool isTrigExpression();
        void setCoefficient(int);
        void setExponent(int);
        void setCoefficientSign(char);
        void setExponentSign(char);
        void setTrigFunction(char *);
        void setTrigCoefficient(int);
        // Used in the Linked List object
        Node * next = nullptr;
    protected:
        // attributes/instance fields
    private:
        int coefficient;
        int exponent;
        char coefficientSign;
        char exponentSign;
        char * trigFunction;
        int trigCoefficient;
};
#endif // NODE_H_INCLUDED
