//Name: Vijayagopal Krishnan (V.J)
//NetID:vxk131830
//CS 1337 S02
// Date: 11/20/2015

#ifndef LINKEDLIST_H_INCLUDED
#define LINKEDLIST_H_INCLUDED

#include "Node.h"

class LinkedList
{
    public:
        LinkedList() {headPointer = nullptr;}
        LinkedList(Node * head)  {headPointer = head;}
        //prototype methods/functions
        void addNode(Node *);
        void deleteNodes();
        void printNodes(fstream&);
        //Accessors
        Node * getHead()
        {
            return headPointer;
        }
        // destructor
        ~LinkedList() {}
    protected:
        //attributes
    private:
        Node * headPointer;
};
#endif // LINKEDLIST_H_INCLUDED
