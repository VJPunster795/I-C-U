//Name: Vijayagopal Krishnan (V.J)
//NetID:vxk131830
//CS 1337 S02
// Date: 11/20/2015

#include "Node.h"
#include <cstring>
#include <iostream>
#include <fstream>
// Default constructor for the Node Class object
Node::Node()
{
    coefficient = 0;
    exponent = 0;
    coefficientSign = '+';
    exponentSign = '+';
    trigFunction = new char;
    trigCoefficient = 0;

}
// Overloaded constructor for the Node Class object
Node:: Node (int coeff, int expo, char coeffSign, char expoSign, char*trigFunc, int trigCoeff)
{
 coefficient = coeff;
 exponent = expo;
 coefficientSign = coeffSign;
 exponentSign = expoSign;
 trigFunction = trigFunc;
 trigCoefficient = trigCoeff;
 next = nullptr;
}
//checks if the trigFunction exists or not
bool Node:: isTrigExpression()
{
    if ((!strcmp(trigFunction, "cos")) || (!strcmp(trigFunction, "sin")) || (!strcmp(trigFunction, "tan"))|| (!strcmp(trigFunction, "sec^2")))
        return true;
    else
        return false;
}
//derives the node
void Node::deriveNode()
{
  if (isTrigExpression())
   {
     if (!strcmp(trigFunction,"cos"))
      {
       if (coefficientSign == '+')
         coefficientSign = '-';
       else
        coefficientSign = '+';
       strcpy(trigFunction, "sin");
     }
    else if (!strcmp(trigFunction,"sin"))
     {
      strcpy(trigFunction, "cos");
     }
    else if (!strcmp(trigFunction, "tan"))
     {
       strcpy(trigFunction, "sec^2");
     }
    coefficient = trigCoefficient * coefficient;
}
else
{
if (exponent == 0)
    coefficient = 0;
else
 {
    if (coefficientSign != exponentSign)
        coefficientSign = '-';
    else
        coefficientSign = '+';
    coefficient = coefficient*exponent;
    exponent = exponent - 1;
 }
}
}
//sets the coefficient to the given parameter/argument
void Node::setCoefficient(int i)
{
    coefficient = i;
}
//sets the exponent to the given parameter/argument
void Node::setExponent(int i)
{
    exponent = i;
}
//sets the coefficient sign to the given parameter/argument
void Node::setCoefficientSign(char ch)
{
    coefficientSign = ch;
}
//sets the exponent sign to the given parameter/argument
void Node::setExponentSign(char ch)
{
    exponentSign = ch;
}
//sets the trig function to the given parameter/argument
void Node::setTrigFunction(char * ch)
{
    strcpy(trigFunction,ch);
}
//sets the trig coefficient to the given parameter/argument
void Node::setTrigCoefficient(int i)
{
    trigCoefficient = i;
}
